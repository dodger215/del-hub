    <nav>
    <img src="logo.png">
    
    <div class="main-nav">
        <span><a href="main.php"><i class="fas fa-box"></i><span class="word"> Orders</span></a></span>
        <span><a href="histroy.php"><i class="fas fa-history"></i><span class="word"> Reminder</span></a></span>
        <span><a href="home.php"><i class="fas fa-house"></i><span class="word">Home</span></a></span>
        <span><a href="notifications.php"><i class="fas fa-bell"></i><span class="word">Notify</span></a></span>
    </div>

    <div class="space"></div>

    <div class="sub-nav">
        <span><i class="fas fa-cog"></i><span class="word"> Settings</span></span>
        <span><a href="logout.php"><i class="fas fa-sign-out-alt"></i><span class="word"> Logout</span></a></span>
    </div>
</nav>
